#pragma once

   #include "../Sources/compilerexception.h"
   #include "../Sources/scanner.h"

namespace scan
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
   using namespace System::IO;


	/// <summary> 
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
   private: System::Windows::Forms::Label *  lblProgram;
   private: System::Windows::Forms::TextBox *  txtFileName;
   private: System::Windows::Forms::Button *  btnBrowse;
   private: System::Windows::Forms::Button *  btnScan;



   private: System::Windows::Forms::Panel *  panel1;
   private: System::Windows::Forms::Splitter *  splitter1;
   private: System::Windows::Forms::OpenFileDialog *  dlgOpenFile;
   private: System::Windows::Forms::RichTextBox *  rtbResults;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
         this->lblProgram = new System::Windows::Forms::Label();
         this->txtFileName = new System::Windows::Forms::TextBox();
         this->btnBrowse = new System::Windows::Forms::Button();
         this->btnScan = new System::Windows::Forms::Button();
         this->panel1 = new System::Windows::Forms::Panel();
         this->splitter1 = new System::Windows::Forms::Splitter();
         this->dlgOpenFile = new System::Windows::Forms::OpenFileDialog();
         this->rtbResults = new System::Windows::Forms::RichTextBox();
         this->panel1->SuspendLayout();
         this->SuspendLayout();
         // 
         // lblProgram
         // 
         this->lblProgram->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
         this->lblProgram->Location = System::Drawing::Point(8, 8);
         this->lblProgram->Name = S"lblProgram";
         this->lblProgram->Size = System::Drawing::Size(96, 16);
         this->lblProgram->TabIndex = 0;
         this->lblProgram->Text = S"MINI Program:";
         // 
         // txtFileName
         // 
         this->txtFileName->Location = System::Drawing::Point(8, 32);
         this->txtFileName->Name = S"txtFileName";
         this->txtFileName->Size = System::Drawing::Size(256, 20);
         this->txtFileName->TabIndex = 2;
         this->txtFileName->Text = S"";
         // 
         // btnBrowse
         // 
         this->btnBrowse->Location = System::Drawing::Point(296, 32);
         this->btnBrowse->Name = S"btnBrowse";
         this->btnBrowse->TabIndex = 3;
         this->btnBrowse->Text = S"Browse...";
         this->btnBrowse->Click += new System::EventHandler(this, btnBrowse_Click);
         // 
         // btnScan
         // 
         this->btnScan->Location = System::Drawing::Point(384, 32);
         this->btnScan->Name = S"btnScan";
         this->btnScan->TabIndex = 5;
         this->btnScan->Text = S"Scan";
         this->btnScan->Click += new System::EventHandler(this, btnScan_Click);
         // 
         // panel1
         // 
         this->panel1->Controls->Add(this->txtFileName);
         this->panel1->Controls->Add(this->lblProgram);
         this->panel1->Controls->Add(this->btnBrowse);
         this->panel1->Controls->Add(this->btnScan);
         this->panel1->Dock = System::Windows::Forms::DockStyle::Top;
         this->panel1->Location = System::Drawing::Point(0, 0);
         this->panel1->Name = S"panel1";
         this->panel1->Size = System::Drawing::Size(488, 72);
         this->panel1->TabIndex = 7;
         // 
         // splitter1
         // 
         this->splitter1->Dock = System::Windows::Forms::DockStyle::Top;
         this->splitter1->Location = System::Drawing::Point(0, 72);
         this->splitter1->Name = S"splitter1";
         this->splitter1->Size = System::Drawing::Size(488, 3);
         this->splitter1->TabIndex = 8;
         this->splitter1->TabStop = false;
         // 
         // dlgOpenFile
         // 
         this->dlgOpenFile->DefaultExt = S"mini";
         this->dlgOpenFile->Filter = S"MINI files (*.mini)|*.mini";
         this->dlgOpenFile->ReadOnlyChecked = true;
         this->dlgOpenFile->Title = S"MINI Program";
         // 
         // rtbResults
         // 
         this->rtbResults->Dock = System::Windows::Forms::DockStyle::Fill;
         this->rtbResults->Font = new System::Drawing::Font(S"Courier New", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
         this->rtbResults->Location = System::Drawing::Point(0, 75);
         this->rtbResults->Name = S"rtbResults";
         this->rtbResults->Size = System::Drawing::Size(488, 266);
         this->rtbResults->TabIndex = 9;
         this->rtbResults->Text = S"";
         // 
         // Form1
         // 
         this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
         this->ClientSize = System::Drawing::Size(488, 341);
         this->Controls->Add(this->rtbResults);
         this->Controls->Add(this->splitter1);
         this->Controls->Add(this->panel1);
         this->Name = S"Form1";
         this->Text = S"MINI Scanner";
         this->panel1->ResumeLayout(false);
         this->ResumeLayout(false);

      }	
   private: System::Void btnBrowse_Click(System::Object *  sender, System::EventArgs *  e)
            {
            if (this->dlgOpenFile->ShowDialog() == DialogResult::OK)
               this->txtFileName->Text = this->dlgOpenFile->FileName;
            }

   private: void ShowError(String *message)
        {
           MessageBox::Show(message, "Error", MessageBoxButtons::OK,
                MessageBoxIcon::Error);
           return;
        }

private: System::Void btnScan_Click(System::Object *  sender, System::EventArgs *  e)
         {
        bool more = true;   // controls loop
        Scanner source;
        PToken nextToken;

        
        String* tokenName[] = 
        { "TKarith", "TKleft", "TKright", "TKsemicolon", "TKrelOp",
        "TKcomma", "TKassign", "TKbreak", "TKcall", "TKelse", "TKend",
        "TKifWhile", "TKint", "TKproc", "TKreadWrite", "TKendFile",
        "TKliteral", "TKsymbol"};

        int nameLength = this->txtFileName->Text->Length;
        if (nameLength == 0)
        {
           ShowError("Choose a file");
           return;
        }

        // See if file exists
        if (!File::Exists(this->txtFileName->Text))
        {
           String *message = String::Format("File does not exist: {0}",
              this->txtFileName->Text);
           ShowError(message);
           return;
        }


        __int8* fileName = new __int8[nameLength + 1];
        String* longFileName = this->txtFileName->Text;

        // Shorten characters to a single byte
        for (int i=0; i<nameLength; ++i)
            fileName[i] = Convert::ToByte(longFileName->get_Chars(i));
        fileName[nameLength] = '\0';

        // Clear text box
        this->rtbResults->Clear();

        try {
            // Open source file
            source.openSourceFile(fileName);

            // Open output file
            FileStream* fs = new FileStream("scan.txt", FileMode::Create,
                FileAccess::Write);
            StreamWriter* sw = new StreamWriter(fs);
            
            sw->WriteLine("File scanned");
            sw->WriteLine(longFileName);
            sw->WriteLine(" ");

            do {
                nextToken = source.nextToken();
                sw->Write(tokenName[nextToken->getTokenType()]->PadRight(15));

                switch (nextToken->getTokenType()) {
                case TKliteral: case TKsymbol:
                   {
                   String *key = new String(nextToken->getKey().c_str());
                   sw->WriteLine(String::Format("{0} ({1})",
                      key, long(nextToken).ToString("x")));
                   }
                   break;
                default:
                   more = nextToken->getTokenType() != TKendFile;
                   sw->WriteLine(nextToken->getKey().c_str());
                }
            }
            while (more);

            sw->Close();
            rtbResults->LoadFile("scan.txt", RichTextBoxStreamType::PlainText);
        }
        catch (CompilerException exc) {
            String* message = String::Format("Error on line {0}: {1}",
                exc.lineNumber.ToString(), Convert::ToString(exc.message.c_str()));
            ShowError(message);
        }
        //catch (Exception* exc) {
        //    ShowError(exc->Message);
        //}
    }
};
}


