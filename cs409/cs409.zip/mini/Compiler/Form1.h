#pragma once

#include "../Sources/compilerexception.h"
#include "../Sources/parser.h"

namespace MiniCompiler
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the 
	///          'Resource File Name' property for the managed resource compiler tool 
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
   private: System::Windows::Forms::Button *  btnCompile;
   private: System::Windows::Forms::CheckBox *  boxDebug;
   private: System::Windows::Forms::Button *  btnBrowse;
   private: System::Windows::Forms::TextBox *  txtFileName;
   private: System::Windows::Forms::Label *  lblProgram;
   private: System::Windows::Forms::OpenFileDialog *  dlgOpenFile;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
         this->btnCompile = new System::Windows::Forms::Button();
         this->boxDebug = new System::Windows::Forms::CheckBox();
         this->btnBrowse = new System::Windows::Forms::Button();
         this->txtFileName = new System::Windows::Forms::TextBox();
         this->lblProgram = new System::Windows::Forms::Label();
         this->dlgOpenFile = new System::Windows::Forms::OpenFileDialog();
         this->SuspendLayout();
         // 
         // btnCompile
         // 
         this->btnCompile->Location = System::Drawing::Point(208, 64);
         this->btnCompile->Name = S"btnCompile";
         this->btnCompile->TabIndex = 9;
         this->btnCompile->Text = S"Compile";
         this->btnCompile->Click += new System::EventHandler(this, btnCompile_Click);
         // 
         // boxDebug
         // 
         this->boxDebug->Checked = true;
         this->boxDebug->CheckState = System::Windows::Forms::CheckState::Checked;
         this->boxDebug->Location = System::Drawing::Point(8, 64);
         this->boxDebug->Name = S"boxDebug";
         this->boxDebug->Size = System::Drawing::Size(144, 24);
         this->boxDebug->TabIndex = 8;
         this->boxDebug->Text = S"Debug Option";
         // 
         // btnBrowse
         // 
         this->btnBrowse->Location = System::Drawing::Point(208, 32);
         this->btnBrowse->Name = S"btnBrowse";
         this->btnBrowse->TabIndex = 7;
         this->btnBrowse->Text = S"Browse...";
         this->btnBrowse->Click += new System::EventHandler(this, btnBrowse_Click);
         // 
         // txtFileName
         // 
         this->txtFileName->Location = System::Drawing::Point(8, 32);
         this->txtFileName->Name = S"txtFileName";
         this->txtFileName->Size = System::Drawing::Size(184, 20);
         this->txtFileName->TabIndex = 6;
         this->txtFileName->Text = S"";
         // 
         // lblProgram
         // 
         this->lblProgram->Font = new System::Drawing::Font(S"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, (System::Byte)0);
         this->lblProgram->Location = System::Drawing::Point(8, 8);
         this->lblProgram->Name = S"lblProgram";
         this->lblProgram->Size = System::Drawing::Size(160, 16);
         this->lblProgram->TabIndex = 5;
         this->lblProgram->Text = S"MINI Program:";
         // 
         // dlgOpenFile
         // 
         this->dlgOpenFile->DefaultExt = S"mini";
         this->dlgOpenFile->Filter = S"MINI Files (*.mini)|*.mini";
         this->dlgOpenFile->ReadOnlyChecked = true;
         // 
         // Form1
         // 
         this->AutoScaleBaseSize = System::Drawing::Size(5, 13);
         this->ClientSize = System::Drawing::Size(292, 101);
         this->Controls->Add(this->btnCompile);
         this->Controls->Add(this->boxDebug);
         this->Controls->Add(this->btnBrowse);
         this->Controls->Add(this->txtFileName);
         this->Controls->Add(this->lblProgram);
         this->Name = S"Form1";
         this->Text = S"MINI Compiler";
         this->ResumeLayout(false);

      }	
   private: System::Void btnBrowse_Click(System::Object *  sender, System::EventArgs *  e)
    {
        if (this->dlgOpenFile->ShowDialog() == DialogResult::OK)
            this->txtFileName->Text = this->dlgOpenFile->FileName;
    }

   private: System::Void btnCompile_Click(System::Object *  sender, System::EventArgs *  e)
    {
        Parser mini;
        int nameLength = this->txtFileName->Text->Length;
        if (nameLength == 0) {   // make sure a file was specified
           MessageBox::Show("Select file...", "Error", MessageBoxButtons::OK,
              MessageBoxIcon::Error);
           return;
        }
        __int8* fileName = new __int8[nameLength + 1];
        String* longFileName = this->txtFileName->Text;

        // Shorten characters to a single byte
        for (int i=0; i<nameLength; ++i)
            fileName[i] = Convert::ToByte(longFileName->get_Chars(i));
        fileName[nameLength] = '\0';

        mini.debugFlag = this->boxDebug->Checked;
        try {
            mini.compile(fileName);
            MessageBox::Show("Successful compilation!", "Success",
                MessageBoxButtons::OK, MessageBoxIcon::Exclamation);
        }
        catch (CompilerException exc) {
            // String conversions needed below because String::Format
            // requires a Microsoft String and not a C++ string
            String* message = String::Format("Error on line {0}: {1}",
                exc.lineNumber.ToString(), Convert::ToString(exc.message.c_str()));
            MessageBox::Show(message, "Error", MessageBoxButtons::OK,
                MessageBoxIcon::Error);
        }
        catch (Exception* exc) {
            MessageBox::Show(exc->Message, "Error", MessageBoxButtons::OK,
                MessageBoxIcon::Error);
        }
        this->Close();
    }

};
}


