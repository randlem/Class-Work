In order to use the SIPS software, you must have a file called .java.property on
your hard disk to give permission to read your SIPS object files.

First copy the SIPS folder to a ZIP disk or flash drive.  Then edit the first
line of the file called .java.policy to indicate the proper device code.  In the
distributed version, the device is identified as "D:".  This is correct for a
ZIP disk in a computer lab, but you might need to change this to use a flash drive
or a personally owned computer.

After you have changed this line, double-click the SIPS-init.bat file to
copy the .java.policy file to the proper location on your hard disk.  This needs
to be done only once for your own computer, but should be done once at the
beginning of each session in a campus computer lab.

If the SIPS.html file doesn't work on the computer, you will need to access the
software using a browser:
   http://voyager.cs.bgsu.edu/rlancast/sips/

