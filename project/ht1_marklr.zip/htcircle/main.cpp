#define DEBUG		1
#define WINDOW_X	501
#define WINDOW_Y	501
#define WINDOW_NAME "Circle Hough Transform"

#define IMG(x,y)     img.pixels[(y)][(x)]
#define IMG_MAP(x,y) img_map[(y) * img.width + (x)]
#define ACCUM(a,b,r) accum[((a) * a_bins) + ((b) * b_bins) + (r)]
#define RANGE(rng)   (rng.high - rng.low)

#include <iostream>
using std::cout;
using std::endl;

#include <string>
using std::string;

#include <math.h>
#include <GL/glut.h>
#include <GL/gl.h>
#include "cs_456_250_setup.h"
#include "util.h"
#include "gfxutil.h"
#include "imgutil.h"

typedef struct {
	double a;
	double b;
	double r;
} circle_t;

typedef struct {
	double low;
	double high;
} range_t;

typedef struct {
	double avg_bin_cnt;
	uint_t max_bin_cnt;
	uint_t filled_bins;
} stats_t;

const string in_file = "edge.png";
const string out_file = "out.png";

const range_t a_range = {0.0, 250.0};
const range_t b_range = {0.0, 250.0};
const range_t r_range = {0.0, sqrt(pow(a_range.high,2) + pow(b_range.high,2))};

img_t    img;
uchar_t* img_map   = NULL;
uint_t*  accum	   = NULL;
stats_t  stats;

uint_t a_bins = 0;
uint_t b_bins = 0;
uint_t r_bins = 0;
uint_t accum_size = 0;

void setup(int*, char**);
void terminate();
void display_func(void);
void keyboard_func(uchar_t, int, int);
void collect_stats();

void translate_img_to_binary(img_t*);
void allocate_accum();
void ht_circle();
void identify_circle(int, circle_t*);

int main (int argc, char *argv[]) {
	setup(&argc,argv);

	if (!loadImage(in_file,&img))
		return 1;

	translate_img_to_binary(&img);
	ht_circle();
	collect_stats();

	// run the OGL main loop
	glutMainLoop();

	return 0;
}

void setup(int* argc, char **argv) {
	img_map = NULL;
	accum = NULL;

	memset(&stats,0,sizeof(stats_t));

	glutInit(argc,argv);
	init_setup(WINDOW_X,WINDOW_Y,WINDOW_NAME);
	glutDisplayFunc(display_func);
	glutKeyboardFunc(keyboard_func);
}

void terminate() {
	if (img_map != NULL) {
		delete [] img_map;
		img_map = NULL;
	}

	if (accum != NULL) {
		delete [] accum;
		accum = NULL;
	}
}

void display_func() {
	int y,x;

	// blank the background
	glClearColor(BLACK.r, BLACK.g, BLACK.b, BLACK.a);
	glClear(GL_COLOR_BUFFER_BIT);

	// draw the frame traces
	glColor4f(ORANGE.r, ORANGE.g, ORANGE.b, ORANGE.a);
	glBegin(GL_LINES);
		glVertex2i(251, 0);
		glVertex2i(251, WINDOW_Y);
		glVertex2i(0, 251);
		glVertex2i(WINDOW_X, 251);
	glEnd();

	// draw the original image in the top left corner
	glBegin(GL_POINTS);
	for (y=0; y < img.height; y++) {
		for (x=0; x < img.width; x++) {
			if (img_map[y * img.width + x] != 0) {
				glColor4f(WHITE.r, WHITE.g, WHITE.b, WHITE.a);
				glVertex2i(x, WINDOW_Y - y);
			}
		}
	}
	glEnd();
	print_string(254, 3, GLUT_BITMAP_9_BY_15, LT_BLUE, "File: %s", in_file.c_str());

	// draw some information in the top right corner
	print_string(WINDOW_Y - 18, 254, GLUT_BITMAP_9_BY_15, WHITE,
		"Filled Bins = %d", stats.filled_bins);
	print_string(WINDOW_Y - 36, 254, GLUT_BITMAP_9_BY_15, WHITE,
		"Max Bin Cnt = %d", stats.max_bin_cnt);
	print_string(WINDOW_Y - 54, 254, GLUT_BITMAP_9_BY_15, WHITE,
		"Avg Bin Cnt = %0.2f", stats.avg_bin_cnt);

	glFlush();
	glutSwapBuffers();
}

void keyboard_func(uchar_t c, int x, int y) {
	switch (c) {
		case 'q':
		case 'Q': {
			terminate();
			exit(0);
		} break;
	}

	glutPostRedisplay();
}

void collect_stats() {
	int a_bin,b_bin,r_bin,curr;

	for (a_bin=0; a_bin < a_bins; a_bin++) {
		for (b_bin=0; b_bin < b_bins; b_bin++) {
			for (r_bin=0; r_bin < r_bins; r_bin++) {
				curr = ACCUM(a_bin,b_bin,r_bin);
				if (curr > 0) {
					stats.filled_bins++;
					if (stats.max_bin_cnt < curr)
						stats.max_bin_cnt = curr;
					stats.avg_bin_cnt += curr;
				}
			}
		}
	}
	stats.avg_bin_cnt = stats.avg_bin_cnt / stats.filled_bins;
}

void translate_img_to_binary(img_t* img) {
	int y,x,map_size;

	map_size = img->height * img->width;
	img_map = new uchar_t[map_size];
	memset(img_map,0,map_size * sizeof(uchar_t));

	for (y=0; y < img->height; y++) {
		for (x=0; x < img->width; x++) {
			img_map[y * img->width + x] = img->pixels[y][x].rgba;
		}
	}
}

void allocate_accum() {
	a_bins     = img.width;
	b_bins     = img.height;
	r_bins     = (uint_t)floor(sqrt(pow((double)a_bins,2) + pow((double)b_bins,2)));
	accum_size = a_bins * b_bins * r_bins;
	accum      = new uint_t[accum_size];
	memset(accum,0,accum_size*sizeof(uint_t));
}

void ht_circle() {
	int y,x,a_bin,b_bin,r_bin;
	double a,b,r,a_pitch,b_pitch,r_pitch;

	allocate_accum();

	a_pitch = RANGE(a_range) / a_bins;
	b_pitch = RANGE(b_range) / b_bins;
	r_pitch = RANGE(r_range) / r_bins;

	for (y=0; y < img.height; y++) {
		for (x=0; x < img.width; x++) {
			if (IMG_MAP(x,y) > 0) {
				for(a=a_range.low; a <= a_range.high; a+=a_pitch) {
					for(b=b_range.low; b <= b_range.high; b+=b_pitch) {
						r = sqrt(pow(x - a,2) + pow(x - b,2));
						a_bin = (int)(a / a_pitch);
						b_bin = (int)(b / b_pitch);
						r_bin = (int)(r / r_pitch);
						ACCUM(a_bin, b_bin, r_bin)++;
					}
				}
			}
		}
	}
}

void identify_circle(int cnt, circle_t* lines) {

}
