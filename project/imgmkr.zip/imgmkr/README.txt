The program is designed to read in commands from a file and
then execute them.  Commands are available for various
drawing parameters including background noise and the level
of pixel displacement.  A couple of different shapes are
available, including lines, ellipses, and circles.

Everything is contained for the most part in the main.cpp
file.  The program requires libpng to compile.
