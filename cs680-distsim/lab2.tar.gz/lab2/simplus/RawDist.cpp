/****************************************************************************

RawDist.cpp

Originally Written by: Mark Randles and Dan Sinclair

For more info see RawDist.h.  Only need to init the static member of RawDist.

****************************************************************************/
#include "RawDist.h"

RNGFactory RawDist::factory;
