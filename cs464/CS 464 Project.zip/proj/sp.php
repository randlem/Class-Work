<? 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: inline; filename=\"hai3.xls\""); 

echo "hi\thai\n";
echo "hello";
?>

