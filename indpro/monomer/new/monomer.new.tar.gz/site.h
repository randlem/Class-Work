#include "point.h"

#ifndef SITE_H
#define SITE_H

typedef struct {
	point position;
	int index;
	int h;
} site;

#endif
