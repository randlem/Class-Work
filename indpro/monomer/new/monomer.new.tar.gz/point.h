#ifndef POINT_H
#define POINT_H

typedef struct {
	int x;
	int y;
} point;

#endif
