/*******************************************************************************
* fcfs.h -- Definition and Implementation of the First Come, First Serve
*     Scheduler Simulator
*
* WRITTEN BY: Mark Randles and Paul Jankura
*
* PURPOSE: The purpose of this class is to simulate as closely as possible a
* First Come, First Serve type scheduling algorithm and collect relevant
* statistics about it.
*
*******************************************************************************/
#ifndef __FCFS_H__
#define __FCFS_H__

#include "processor.h"

class Processor_FCFS : public Processor {
public:
	Processor_FCFS() {
		processor_name = "First Come, First Serve";
	}

	void simulate() {
		Process_ptr p = NULL;
		double next_time = 0.0;

		// while there is a process in the arrival queue
		while(!arrival_queue.empty()) {
			// get the next process
			p = arrival_queue.front();

			// calc the next timestamp
			next_time = p->time_left + time;

			// record some statistics about the processor
			time_process.observe(time, p->time_left);
			time_wait.observe(time, time - p->time_arrival);
			time_response.observe(time, time - p->time_arrival);
			time_turnaround.observe(time, p->time_left);
			finished++;

			// set the current time to whatever the time is at the end of the process
			time = next_time;

			// pop the finished process off the stack
			arrival_queue.pop();

			// clear up memory
			delete p;
		}
	}

private:

};

#endif
